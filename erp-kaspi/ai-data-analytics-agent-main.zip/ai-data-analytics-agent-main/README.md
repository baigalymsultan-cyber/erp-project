# 🤖 AI Data Analytics Agent

A powerful AI agent that analyzes your CSV data using natural language queries with real-time monitoring.

## ✨ Features

- 📊 **Natural Language to SQL**: Ask questions in plain English
- 📈 **Real-time Monitoring**: Prometheus metrics + Grafana dashboards
- 🔄 **Multi-file Support**: Upload different CSV files seamlessly
- ⚡ **Fast Response**: Optimized query processing
- 🎯 **Interactive Web UI**: User-friendly Streamlit interface

## 🏗️ Technical Architecture

```mermaid
graph TD
    subgraph "Presentation Layer"
        UI[Streamlit Web Interface]
    end
  
    subgraph "Agent Layer"
        AGENT[PrometheusMonitoredAgent]
        SQL[SQLAgent]
        GRAPH[LangGraph State Machine]
    end
  
    subgraph "AI Services"
        OPENAI[Azure OpenAI GPT-4o]
        CHAIN[LangChain SQL Chain]
        HUB[LangChain Hub Prompts]
    end
  
    subgraph "Data Processing"
        DUCK[DuckDB Query Engine]
        SCHEMA[Schema Analyzer]
        CSV[CSV Document Loader]
    end
  
    subgraph "Monitoring"
        METRICS[Prometheus Metrics]
        DASHBOARD[Grafana Dashboard]
    end
  
    UI --> AGENT
    AGENT --> SQL
    SQL --> GRAPH
  
    GRAPH --> CHAIN
    CHAIN --> HUB
    HUB --> OPENAI
    OPENAI --> CHAIN
    CHAIN --> GRAPH
  
    SQL --> SCHEMA
    SCHEMA --> DUCK
    CSV --> DUCK
    DUCK --> SQL
  
    AGENT --> METRICS
    METRICS --> DASHBOARD
  
    classDef presentation fill:#e3f2fd,stroke:#1976d2,stroke-width:2px
    classDef agent fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px
    classDef ai fill:#e8f5e8,stroke:#388e3c,stroke-width:2px
    classDef data fill:#fff3e0,stroke:#f57c00,stroke-width:2px
    classDef monitoring fill:#fce4ec,stroke:#c2185b,stroke-width:2px
  
    class UI presentation
    class AGENT,SQL,GRAPH agent
    class OPENAI,CHAIN,HUB ai
    class DUCK,SCHEMA,CSV data
    class METRICS,DASHBOARD monitoring
```

```

```

```

```

## 🏗️ Technical Flow Architecture

```mermaid
flowchart TD
    Start([User asks natural language question]) --> Upload{File uploaded?}
  
    Upload -->|No| UploadFile[Upload CSV/Excel file<br/>- Create unique filename with UUID<br/>- Store in temp_data/ directory<br/>- Convert Excel to CSV if needed]
  
    UploadFile --> InitAgent[Initialize PrometheusMonitoredAgent<br/>- Start metrics HTTP server on port 8000<br/>- Initialize shared Prometheus metrics<br/>- Create SQLAgent with file path]
  
    Upload -->|Yes| SchemaAnalysis
    InitAgent --> SchemaAnalysis[Schema Analysis Phase<br/>- Connect to DuckDB<br/>- Execute DESCRIBE query on CSV<br/>- Get column names and data types<br/>- Extract 3 sample rows<br/>- Format schema information]
  
    SchemaAnalysis --> QueryProcessing[Query Processing Starts<br/>- Record start timestamp<br/>- Track question length in histogram<br/>- Increment query counter]
  
    QueryProcessing --> SQLGeneration[SQL Generation Phase<br/>- Pull langchain-ai/sql-query-system-prompt<br/>- Enhance prompt with schema info<br/>- Call Azure OpenAI GPT-4o-mini<br/>- Extract SQL from LLM response using regex]
  
    SQLGeneration --> SQLValidation{SQL Valid?}
  
    SQLValidation -->|Invalid| ErrorHandling[Error Handling<br/>- Increment error counter<br/>- Log error type and session ID<br/>- Return error with debug info]
  
    SQLValidation -->|Valid| SQLExecution[SQL Execution Phase<br/>- Use DuckDBLoader with generated SQL<br/>- Execute query against CSV file<br/>- Handle connection and result parsing]
  
    SQLExecution --> ExecutionCheck{Execution Success?}
  
    ExecutionCheck -->|Failed| ErrorHandling
  
    ExecutionCheck -->|Success| AnswerGeneration[Answer Generation Phase<br/>- Create context prompt with:<br/>  * Original question<br/>  * Generated SQL query<br/>  * Query results<br/>- Call Azure OpenAI for natural language answer]
  
    AnswerGeneration --> MetricsRecording[Metrics Recording<br/>- Record total query duration<br/>- Track SQL generation time<br/>- Track execution time<br/>- Update success/error counters<br/>- Log session ID and file path]
  
    MetricsRecording --> ResponseFormatting[Response Formatting<br/>- Structure result with:<br/>  * Natural language answer<br/>  * Generated SQL query<br/>  * Raw query results<br/>  * Performance metadata<br/>  * Session information]
  
    ResponseFormatting --> UIDisplay[Streamlit UI Display<br/>- Show natural language answer<br/>- Display SQL query in code block<br/>- Show query results in expander<br/>- Display performance metrics<br/>- Update monitoring dashboard links]
  
    UIDisplay --> MonitoringUpdate[Background Monitoring<br/>- CPU usage via psutil<br/>- Memory usage tracking<br/>- Active session counting<br/>- Prometheus metrics export<br/>- Grafana dashboard updates]
  
    MonitoringUpdate --> End([Query Complete])
  
    %% Parallel Monitoring Process
    Start --> SystemMonitoring[System Monitoring Thread<br/>- Monitor CPU every 5 seconds<br/>- Track memory usage<br/>- Update Prometheus gauges<br/>- Export metrics on :8000/metrics]
  
    SystemMonitoring --> PrometheusScaping[Prometheus Scraping<br/>- Scrape metrics every 5 seconds<br/>- Store time-series data<br/>- Evaluate alert rules<br/>- Trigger notifications if needed]
  
    PrometheusScaping --> GrafanaVisualization[Grafana Visualization<br/>- Query Prometheus data<br/>- Update dashboard panels<br/>- Show real-time metrics<br/>- Display performance trends]
  
    %% Error Recovery Path
    ErrorHandling --> ErrorResponse[Error Response<br/>- Format error message<br/>- Include debugging information<br/>- Show generated SQL for troubleshooting<br/>- Display file path and existence check]
  
    ErrorResponse --> UIDisplay
  
    %% Styling
    classDef processBox fill:#e3f2fd,stroke:#1976d2,stroke-width:2px
    classDef decisionBox fill:#fff3e0,stroke:#f57c00,stroke-width:2px
    classDef errorBox fill:#ffebee,stroke:#d32f2f,stroke-width:2px
    classDef monitorBox fill:#e8f5e8,stroke:#388e3c,stroke-width:2px
    classDef startEnd fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px
  
    class SchemaAnalysis,QueryProcessing,SQLGeneration,SQLExecution,AnswerGeneration,MetricsRecording,ResponseFormatting,UIDisplay,UploadFile,InitAgent processBox
    class Upload,SQLValidation,ExecutionCheck decisionBox
    class ErrorHandling,ErrorResponse errorBox
    class SystemMonitoring,PrometheusScaping,GrafanaVisualization,MonitoringUpdate monitorBox
    class Start,End startEnd
```

## 🔧 Technical Specifications

### Communication Protocols

- **Frontend**: HTTP/1.1, WebSocket (Streamlit server-client)
- **AI Services**: HTTPS/REST with Bearer token authentication
- **Monitoring**: HTTP metrics endpoint (Prometheus pull model)
- **Container Network**: Docker bridge network with port mapping

### Data Formats

- **Input**: CSV (UTF-8), Excel (XLSX/XLS)
- **Internal**: Python TypedDict state objects
- **AI API**: JSON request/response payloads
- **Metrics**: Prometheus exposition format
- **Configuration**: YAML (Docker/Grafana), JSON (dashboards)

### Storage & Persistence

- **Temporary Files**: File system with UUID-based naming
- **Database**: In-memory DuckDB with CSV auto-detection
- **Metrics**: Time-series database (Prometheus TSDB)
- **Configuration**: Environment variables and mounted volumes

### Concurrency & Threading

- **Main Process**: Streamlit WSGI server
- **Background Threads**: System monitoring (psutil), metrics server
- **Session Management**: Streamlit session state with UUID tracking
- **Resource Sharing**: Class-level shared Prometheus metrics registry

### Security & Configuration

- **API Authentication**: Azure AD token-based authentication
- **Environment Isolation**: Docker containers with resource limits
- **Secrets Management**: Environment variables (not committed)
- **Network Isolation**: Container networking with controlled port exposure

## 🔄 Detailed Technical Process

### Phase 1: File Processing

1. **File Upload**: Streamlit file uploader accepts CSV/Excel files
2. **UUID Generation**: Create unique 8-character identifier for file isolation
3. **Path Creation**: Store in `temp_data/data_{uuid}.csv` format
4. **Format Conversion**: Convert Excel files to CSV using pandas `read_excel()` and `to_csv()`
5. **Persistence**: Write file to disk for DuckDB access

### Phase 2: Agent Initialization

1. **Metrics Server**: Start HTTP server on port 8000 using `prometheus_client.start_http_server()`
2. **Shared Metrics**: Initialize Counter, Histogram, and Gauge metrics in default registry
3. **System Monitor**: Launch background thread monitoring CPU/Memory via `psutil`
4. **Session Tracking**: Increment active sessions gauge, assign unique session ID

### Phase 3: Schema Discovery

1. **DuckDB Connection**: Create in-memory DuckDB connection
2. **Schema Query**: Execute `DESCRIBE SELECT * FROM read_csv_auto('{file_path}') LIMIT 1`
3. **Sample Data**: Query `SELECT * FROM read_csv_auto('{file_path}') LIMIT 3`
4. **Metadata Extraction**: Parse column names, data types, and sample values
5. **Context Building**: Format schema information for LLM prompt enhancement

### Phase 4: SQL Generation

1. **Prompt Template**: Pull `langchain-ai/sql-query-system-prompt` from LangChain Hub
2. **Context Enhancement**: Inject schema info, column names, and sample data
3. **LLM Invocation**: Call Azure OpenAI GPT-4o-mini with enhanced prompt
4. **Response Parsing**: Extract SQL using regex patterns for code blocks and SELECT statements
5. **Query Validation**: Basic syntax checking and formatting

### Phase 5: Query Execution

1. **DuckDB Loader**: Use `DuckDBLoader` with generated SQL query
2. **File Access**: DuckDB reads CSV directly using `read_csv_auto()` function
3. **Query Processing**: Execute SQL with automatic type inference
4. **Result Handling**: Parse results into LangChain Document format
5. **Error Management**: Catch SQL errors and format for user display

### Phase 6: Answer Generation

1. **Context Assembly**: Combine original question, SQL query, and results
2. **Prompt Creation**: Structure context for natural language response generation
3. **LLM Response**: Second Azure OpenAI call for answer synthesis
4. **Content Extraction**: Parse natural language answer from LLM response

### Phase 7: Metrics & Monitoring

1. **Timing Metrics**: Record query duration in histogram buckets
2. **Counter Updates**: Increment success/error counters with labels
3. **Performance Tracking**: Log SQL generation, execution, and answer times
4. **Session Metadata**: Associate all metrics with session ID and file path
5. **Real-time Export**: Expose metrics on `/metrics` endpoint for Prometheus

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Set Up Environment

Create `.env` file:

```
AZURE_OPENAI_API_KEY=your_key_here
AZURE_OPENAI_ENDPOINT=your_endpoint_here
AZURE_OPENAI_DEPLOYMENT_NAME=your_deployment_name
```

### 3. Start Monitoring (Optional)

```bash
docker-compose up -d
```

### 4. Run the Application

```bash
# Option 1: Use the launcher (recommended)
python run.py

# Option 2: Direct Streamlit
streamlit run app.py
```

## 📁 Project Structure

```
ai-data-analytics-agent/
├── app.py                     # Main Streamlit application
├── run.py                     # Application launcher
├── requirements.txt           # Python dependencies
├── docker-compose.yml         # Monitoring stack
├── .env                      # Environment variables
│
├── src/
│   ├── agent/
│   │   ├── sql_agent.py           # Core AI agent
│   │   ├── prometheus_monitored_agent.py  # Monitored version
│   │   └── state.py               # Agent state definitions
│   └── utils/
│       └── config.py              # Configuration
│
├── monitoring/
│   ├── prometheus.yml             # Prometheus config
│   ├── alerts.yml                # Alert definitions
│   └── grafana/
│       ├── provisioning/
│       └── dashboards/
│
└── temp_data/                     # Temporary CSV storage
```

## 🎯 How to Use

1. **Upload CSV**: Drag & drop your CSV file
2. **Ask Questions**: Type natural language questions like:
   - "How many records are in the dataset?"
   - "What's the average salary?"
   - "Show me the top 5 sales by region"
3. **View Results**: Get instant answers with SQL queries shown
4. **Monitor Performance**: Check Grafana at http://localhost:3000

## 📊 Monitoring

- **Metrics**: http://localhost:8000/metrics
- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:3000 (admin/admin123)

## 🔧 Configuration

Edit `src/utils/config.py` to customize:

- Model parameters
- API endpoints
- Default settings

## 💡 Example Questions

- "How many rows are in my data?"
- "What columns are available?"
- "Show me summary statistics"
- "Find records where sales > 1000"
- "Group by category and count"

## 🐛 Troubleshooting

**CSV not loading?**

- Check file format (CSV, Excel supported)
- Verify file path exists

**Metrics not showing?**

- Ensure Docker is running: `docker-compose ps`
- Check metrics endpoint: http://localhost:8000/metrics

**AI not responding?**

- Verify `.env` file has correct Azure OpenAI credentials
- Check API quota and deployment status
