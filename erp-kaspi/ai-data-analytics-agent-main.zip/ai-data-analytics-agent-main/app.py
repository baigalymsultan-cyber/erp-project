import streamlit as st
import pandas as pd
import tempfile
import os
from src.agent.prometheus_monitored_agent import PrometheusMonitoredAgent
import uuid
import shutil
from pathlib import Path

def create_persistent_csv(uploaded_file):
    """Create a persistent CSV file from uploaded file"""
    # Create a data directory in the project
    data_dir = Path("temp_data")
    data_dir.mkdir(exist_ok=True)
    
    # Create a unique filename
    file_id = str(uuid.uuid4())[:8]
    file_extension = uploaded_file.name.split('.')[-1]
    persistent_path = data_dir / f"data_{file_id}.csv"
    
    try:
        if uploaded_file.name.endswith('.csv'):
            # Direct CSV file
            with open(persistent_path, 'wb') as f:
                f.write(uploaded_file.read())
        else:
            # Convert Excel to CSV
            # Reset file pointer for reading
            uploaded_file.seek(0)
            df = pd.read_excel(uploaded_file)
            df.to_csv(persistent_path, index=False)
        
        return str(persistent_path.absolute())
        
    except Exception as e:
        raise Exception(f"Error creating persistent file: {str(e)}")

def cleanup_old_files():
    """Clean up old temporary files"""
    data_dir = Path("temp_data")
    if data_dir.exists():
        import time
        current_time = time.time()
        for file_path in data_dir.glob("data_*.csv"):
            # Remove files older than 1 hour
            if current_time - file_path.stat().st_mtime > 3600:
                try:
                    file_path.unlink()
                except:
                    pass

def main():
    st.set_page_config(page_title="AI Data Analytics Agent", layout="wide")
    
    st.title("🤖 AI Data Analytics Agent")
    st.write("Upload your data and ask any question using advanced SQL generation!")
    
    # Initialize session state with better defaults
    if 'agent' not in st.session_state:
        st.session_state.agent = None
    if 'data_info' not in st.session_state:
        st.session_state.data_info = None
    if 'session_id' not in st.session_state:
        st.session_state.session_id = str(uuid.uuid4())[:8]
    if 'csv_file_path' not in st.session_state:
        st.session_state.csv_file_path = None
    if 'current_file_name' not in st.session_state:
        st.session_state.current_file_name = None
    
    # Clean up old files
    cleanup_old_files()
    
    # File upload
    with st.sidebar:
        st.header("📁 Data Upload")
        uploaded_file = st.file_uploader("Choose a file", type=['csv', 'xlsx', 'xls'])
        
        # Check if a new file is uploaded
        if uploaded_file and uploaded_file.name != st.session_state.current_file_name:
            try:
                # Clean up old agent if exists
                if st.session_state.agent:
                    try:
                        st.session_state.agent.shutdown()
                    except Exception as e:
                        print(f"Error shutting down old agent: {e}")
                
                # Create persistent CSV file
                csv_path = create_persistent_csv(uploaded_file)
                st.session_state.csv_file_path = csv_path
                st.session_state.current_file_name = uploaded_file.name
                
                # Generate new session ID for new file
                st.session_state.session_id = str(uuid.uuid4())[:8]
                
                # Initialize NEW SQL agent with monitoring
                st.session_state.agent = PrometheusMonitoredAgent(
                    csv_path=csv_path,
                    session_id=st.session_state.session_id,
                    metrics_port=8000
                )
                
                # Get data info
                df = pd.read_csv(csv_path)
                st.session_state.data_info = {
                    'shape': df.shape,
                    'columns': list(df.columns),
                    'dtypes': df.dtypes.to_dict(),
                    'file_name': uploaded_file.name,
                    'file_path': csv_path
                }
                
                st.success("✅ New data loaded successfully!")
                st.write(f"**File:** {uploaded_file.name}")
                st.write(f"**Shape:** {st.session_state.data_info['shape']}")
                st.write(f"**Columns:** {', '.join(st.session_state.data_info['columns'])}")
                
                # Show metrics endpoint
                if hasattr(st.session_state.agent, 'get_metrics_url'):
                    st.info(f"📊 Metrics available at: {st.session_state.agent.get_metrics_url()}")
                
                # Force rerun to update the interface
                st.rerun()
                
            except Exception as e:
                st.error(f"Error loading data: {str(e)}")
                st.session_state.agent = None
                st.session_state.data_info = None
                st.session_state.current_file_name = None
        
        elif uploaded_file and uploaded_file.name == st.session_state.current_file_name:
            # Same file, show current info
            if st.session_state.data_info:
                st.success("✅ Data already loaded")
                st.write(f"**File:** {st.session_state.data_info['file_name']}")
                st.write(f"**Shape:** {st.session_state.data_info['shape']}")
                st.write(f"**Columns:** {', '.join(st.session_state.data_info['columns'])}")
    
    # Handle case where user opens new tab without uploading file
    if not uploaded_file and st.session_state.current_file_name:
        st.sidebar.warning("⚠️ File was uploaded in another tab. Please re-upload to use in this tab.")
    
    # Main interface
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.header("💬 Ask Any Question")
        
        # Show current file info
        if st.session_state.data_info:
            st.info(f"🎯 **Currently analyzing:** {st.session_state.data_info['file_name']}")
            
            with st.expander("💡 Example Questions"):
                st.write("• How many records are in the dataset?")
                st.write("• What columns are available?")
                st.write("• Show me the first 5 rows")
                st.write("• What's the average value of [column_name]?")
                st.write("• Count records by [category_column]")
                st.write("• Show records where [column] > value")
        
        query = st.text_input(
            "Enter your question:", 
            placeholder="e.g., 'How many records are in the dataset?'"
        )
        
        if st.button("🔍 Analyze", type="primary"):
            if not query:
                st.warning("Please enter a question")
            elif st.session_state.agent is None:
                st.warning("Please upload data first")
            else:
                with st.spinner("🧠 Processing your question..."):
                    try:
                        # Verify agent is properly initialized
                        if not hasattr(st.session_state.agent, 'query_counter'):
                            st.error("❌ Agent not properly initialized. Please re-upload your file.")
                            return
                        
                        # Query the agent
                        result = st.session_state.agent.query(query)
                        
                        if 'error' in result:
                            st.error(f"❌ Error: {result['error']}")
                            
                            # Show query details for debugging
                            if 'query' in result:
                                with st.expander("🔍 Generated SQL (for debugging)"):
                                    st.code(result['query'], language='sql')
                                    st.write(f"**File path used:** {st.session_state.csv_file_path}")
                                    st.write(f"**File exists:** {os.path.exists(st.session_state.csv_file_path) if st.session_state.csv_file_path else 'N/A'}")
                        else:
                            st.success("✅ Analysis Complete!")
                            
                            # Show the answer
                            if 'answer' in result:
                                st.info(f"💡 **Answer:** {result['answer']}")
                            
                            # Show the generated SQL query
                            if 'query' in result:
                                with st.expander("🔍 Generated SQL Query"):
                                    st.code(result['query'], language='sql')
                            
                            # Show query results if available
                            if 'result' in result and result['result']:
                                with st.expander("📊 Query Results"):
                                    try:
                                        # Extract data from LangChain documents
                                        if hasattr(result['result'][0], 'page_content'):
                                            # This is from DuckDBLoader - parse the content
                                            content = result['result'][0].page_content
                                            if content and not content.startswith('Error'):
                                                st.text(content)
                                        else:
                                            # Direct data
                                            st.write(result['result'])
                                    except Exception as e:
                                        st.write("Results processed successfully")
                            
                            # Show performance metrics if available
                            if 'metadata' in result:
                                with st.expander("⚡ Performance Metrics"):
                                    metadata = result['metadata']
                                    col_a, col_b, col_c = st.columns(3)
                                    
                                    with col_a:
                                        st.metric("Total Time", f"{metadata.get('total_time', 0):.2f}s")
                                    with col_b:
                                        st.metric("SQL Generation", f"{metadata.get('sql_generation_time', 0):.2f}s")
                                    with col_c:
                                        st.metric("Session ID", metadata.get('session_id', 'N/A'))
                        
                    except AttributeError as e:
                        st.error(f"❌ Agent initialization error: {str(e)}")
                        st.info("💡 Try re-uploading your file to fix this issue")
                        # Reset agent to force re-initialization
                        st.session_state.agent = None
                        
                    except Exception as e:
                        st.error(f"❌ Unexpected error: {str(e)}")
    
    with col2:
        st.header("📋 Data Info")
        
        if st.session_state.data_info is not None:
            info = st.session_state.data_info
            
            # Basic info
            st.write(f"**File:** {info['file_name']}")
            st.write(f"**Rows:** {info['shape'][0]:,}")
            st.write(f"**Columns:** {info['shape'][1]}")
            st.write(f"**Session:** {st.session_state.session_id}")
            
            # Show file path for debugging
            if st.checkbox("Show debug info"):
                st.write(f"**File Path:** {info.get('file_path', 'N/A')}")
                st.write(f"**File Exists:** {os.path.exists(info.get('file_path', '')) if info.get('file_path') else 'N/A'}")
            
            # Column info
            st.write("**Column Details:**")
            for col, dtype in info['dtypes'].items():
                st.write(f"• **{col}** ({dtype})")
            
            # Quick data preview if agent is available
            if st.session_state.agent:
                if st.button("👀 Preview Data"):
                    with st.spinner("Loading preview..."):
                        try:
                            preview_result = st.session_state.agent.query("Show me the first 5 rows")
                            if 'result' in preview_result and preview_result['result']:
                                content = preview_result['result'][0].page_content
                                st.text(content)
                        except Exception as e:
                            st.error(f"Preview failed: {str(e)}")
        else:
            st.info("📤 Upload data to see information")
        
        # Monitoring info
        st.header("📊 Monitoring")
        if st.session_state.agent:
            st.success("✅ Monitoring Active")
            st.write(f"**Session:** {st.session_state.session_id}")
            
            # Links to monitoring dashboards
            st.markdown("**Dashboards:**")
            st.markdown("• [Metrics](http://localhost:8000/metrics)")
            st.markdown("• [Prometheus](http://localhost:9090)")
            st.markdown("• [Grafana](http://localhost:3000)")
            
            # Add a test button to generate some metrics
            if st.button("🧪 Test Metrics"):
                try:
                    test_result = st.session_state.agent.query("How many records are in this dataset?")
                    st.success("✅ Test query executed - check metrics!")
                except Exception as e:
                    st.error(f"Test failed: {e}")
        else:
            st.warning("⚠️ Upload data to enable monitoring")

if __name__ == "__main__":
    main()