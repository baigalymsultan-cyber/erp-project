import os
import re
import duckdb
from typing import Dict, Any
from langchain_openai import AzureChatOpenAI
from langchain import hub
from langchain_community.document_loaders import DuckDBLoader
from langgraph.graph import START, StateGraph
from .state import State, QueryOutput
from ..utils.config import Config


class SQLAgent:
    def __init__(self, file_path: str, deployment_name: str = None):
        """
        Initialize the SQL Agent

        Args:
            file_path (str): Path to the CSV file
            deployment_name (str): Azure deployment name (if using Azure OpenAI)
        """
        self.file_path = file_path

        # Use Azure OpenAI only
        self.llm = AzureChatOpenAI(
            azure_deployment=Config.AZURE_OPENAI_DEPLOYMENT_NAME,
            api_version=Config.AZURE_OPENAI_API_VERSION,
            temperature=Config.DEFAULT_TEMPERATURE,
            azure_endpoint=Config.AZURE_OPENAI_ENDPOINT,
            api_key=Config.AZURE_OPENAI_API_KEY
        )

        # Load the SQL query prompt template from LangChain hub
        self.query_prompt_template = hub.pull("langchain-ai/sql-query-system-prompt")

        # Get schema information
        self.schema_info = self._get_schema_info()

        # Build the workflow graph
        self.graph = self._build_graph()

    def _get_schema_info(self) -> str:
        """Get schema information from the CSV file."""
        try:
            # Connect to DuckDB and analyze the CSV
            conn = duckdb.connect()

            # Get column information
            schema_query = f"DESCRIBE SELECT * FROM read_csv_auto('{self.file_path}') LIMIT 1"
            schema_result = conn.execute(schema_query).fetchall()

            # Get sample data
            sample_query = f"SELECT * FROM read_csv_auto('{self.file_path}') LIMIT 3"
            sample_result = conn.execute(sample_query).fetchall()
            sample_columns = [desc[0] for desc in conn.description]

            conn.close()

            # Format schema information
            schema_info = f"Table: read_csv_auto('{self.file_path}')\n\n"
            schema_info += "Columns:\n"
            for col_name, col_type, *_ in schema_result:
                schema_info += f"- {col_name} ({col_type})\n"

            schema_info += "\nSample data:\n"
            for i, row in enumerate(sample_result):
                row_data = ", ".join([f"{col}: {val}" for col, val in zip(sample_columns, row)])
                schema_info += f"Row {i + 1}: {row_data}\n"

            return schema_info

        except Exception as e:
            print(f"Warning: Could not get schema info: {e}")
            return f"Table: read_csv_auto('{self.file_path}')"

    def write_query(self, state: State) -> Dict[str, str]:
        """Generate SQL query to fetch information."""
        # Create enhanced prompt with schema information
        enhanced_input = f"""
Schema Information:
{self.schema_info}

User Question: {state["question"]}

Please generate a SQL query using the exact column names shown above.
"""

        prompt = self.query_prompt_template.invoke({
            "dialect": "duckdb",
            "top_k": 10,
            "table_info": f"read_csv_auto('{self.file_path}')",
            "input": enhanced_input,
        })

        # Use regular invoke instead of structured output
        response = self.llm.invoke(prompt)

        # Extract SQL query from the response
        sql_query = self._extract_sql_from_response(response.content)

        return {"query": sql_query}

    def _extract_sql_from_response(self, response_text: str) -> str:
        """Extract SQL query from LLM response."""
        # Look for SQL query patterns
        sql_patterns = [
            r'```sql\s*(.*?)\s*```',  # SQL code blocks
            r'```\s*(SELECT.*?);?\s*```',  # Generic code blocks with SELECT
            r'SQLQuery:\s*(.*?)(?:\n|$)',  # SQLQuery: format
            r'(SELECT.*?);?(?:\n|$)',  # Direct SELECT statements
        ]

        for pattern in sql_patterns:
            matches = re.findall(pattern, response_text, re.DOTALL | re.IGNORECASE)
            if matches:
                sql_query = matches[0].strip()
                # Clean up the query
                sql_query = sql_query.replace('\n', ' ').strip()
                if sql_query.endswith(';'):
                    sql_query = sql_query[:-1]
                return sql_query

        # If no pattern matches, return the whole response (fallback)
        return response_text.strip()

    def execute_query(self, state: State) -> Dict[str, list]:
        """Execute SQL query against DuckDB."""
        try:
            data = DuckDBLoader(state["query"]).load()
            return {'result': data}
        except Exception as e:
            # Return error information
            from langchain.schema import Document
            error_msg = f"Error executing query: {str(e)}\n\nQuery was: {state['query']}\n\nAvailable columns from schema:\n{self.schema_info}"
            error_doc = [Document(metadata={}, page_content=error_msg)]
            return {'result': error_doc}

    def generate_answer(self, state: State) -> Dict[str, str]:
        """Answer question using retrieved information as context."""
        # Check if result contains an error
        if state["result"] and "Error executing query" in state["result"][0].page_content:
            return {"answer": f"I encountered an error with the SQL query. {state['result'][0].page_content}"}

        prompt = (
            "Given the following user question, corresponding SQL query, "
            "and SQL result, answer the user question.\n\n"
            f'Question: {state["question"]}\n'
            f'SQL Query: {state["query"]}\n'
            f'SQL Result: {state["result"]}'
        )

        response = self.llm.invoke(prompt)
        return {"answer": response.content}

    def _build_graph(self):
        """Build the LangGraph workflow."""
        graph_builder = StateGraph(State).add_sequence([
            self.write_query,
            self.execute_query,
            self.generate_answer
        ])

        graph_builder.add_edge(START, "write_query")
        return graph_builder.compile()

    def query(self, question: str, stream: bool = False) -> Dict[str, Any]:
        """
        Process a natural language question and return the answer.

        Args:
            question (str): Natural language question about the data
            stream (bool): Whether to stream intermediate results

        Returns:
            Dict containing the final answer and intermediate steps
        """
        if stream:
            results = {}
            for step in self.graph.stream({"question": question}, stream_mode="updates"):
                results.update(step)
                print(step)
            return results
        else:
            return self.graph.invoke({"question": question})