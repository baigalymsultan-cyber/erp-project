import time
import psutil
import threading
from prometheus_client import Counter, Histogram, Gauge, start_http_server, REGISTRY
from .sql_agent import SQLAgent


class PrometheusMonitoredAgent:
    # Class-level shared metrics (use default registry)
    _metrics_server_started = False
    _shared_metrics = {}

    def __init__(self, csv_path: str, session_id: str = "default", metrics_port: int = 8000):
        # Initialize base agent with new CSV path
        self.agent = SQLAgent(csv_path)
        self.session_id = session_id
        self.metrics_port = metrics_port
        self.csv_path = csv_path

        # Initialize metrics (create once, reuse for all instances)
        self._init_shared_metrics()

        # Start metrics server only once
        if not PrometheusMonitoredAgent._metrics_server_started:
            self._start_metrics_server()
            self._start_system_monitoring()
            PrometheusMonitoredAgent._metrics_server_started = True

        # Increment active sessions
        self.active_sessions.inc()

        print(f"✅ Agent initialized with CSV: {csv_path}")

    def _init_shared_metrics(self):
        """Initialize shared Prometheus metrics using default registry"""
        if not PrometheusMonitoredAgent._shared_metrics:
            try:
                # Query metrics
                PrometheusMonitoredAgent._shared_metrics['query_counter'] = Counter(
                    'agent_queries_total',
                    'Total number of queries processed',
                    ['status', 'session_id']
                )

                PrometheusMonitoredAgent._shared_metrics['query_duration'] = Histogram(
                    'agent_query_duration_seconds',
                    'Time spent processing queries',
                    ['session_id'],
                    buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0]
                )

                PrometheusMonitoredAgent._shared_metrics['question_length'] = Histogram(
                    'agent_question_length_chars',
                    'Length of questions in characters',
                    buckets=[10, 50, 100, 200, 500, 1000]
                )

                # System metrics
                PrometheusMonitoredAgent._shared_metrics['cpu_usage'] = Gauge(
                    'agent_cpu_usage_percent',
                    'CPU usage percentage'
                )
                
                PrometheusMonitoredAgent._shared_metrics['memory_usage'] = Gauge(
                    'agent_memory_usage_bytes',
                    'Memory usage in bytes'
                )
                
                PrometheusMonitoredAgent._shared_metrics['active_sessions'] = Gauge(
                    'agent_active_sessions',
                    'Number of active sessions'
                )

                # Error tracking
                PrometheusMonitoredAgent._shared_metrics['error_counter'] = Counter(
                    'agent_errors_total',
                    'Total number of errors',
                    ['error_type', 'session_id']
                )

                # Component timing
                PrometheusMonitoredAgent._shared_metrics['sql_generation_time'] = Histogram(
                    'agent_sql_generation_seconds',
                    'Time spent generating SQL',
                    buckets=[0.1, 0.5, 1.0, 2.0, 5.0]
                )

                PrometheusMonitoredAgent._shared_metrics['sql_execution_time'] = Histogram(
                    'agent_sql_execution_seconds',
                    'Time spent executing SQL',
                    buckets=[0.01, 0.1, 0.5, 1.0, 2.0]
                )

                PrometheusMonitoredAgent._shared_metrics['answer_generation_time'] = Histogram(
                    'agent_answer_generation_seconds',
                    'Time spent generating answers',
                    buckets=[0.1, 0.5, 1.0, 2.0, 5.0]
                )

                # Initialize active sessions to 0
                PrometheusMonitoredAgent._shared_metrics['active_sessions'].set(0)

                print("✅ Shared metrics initialized with default registry")

            except Exception as e:
                print(f"Error initializing shared metrics: {e}")

        # Set instance attributes to point to shared metrics
        self.query_counter = PrometheusMonitoredAgent._shared_metrics['query_counter']
        self.query_duration = PrometheusMonitoredAgent._shared_metrics['query_duration']
        self.question_length = PrometheusMonitoredAgent._shared_metrics['question_length']
        self.cpu_usage = PrometheusMonitoredAgent._shared_metrics['cpu_usage']
        self.memory_usage = PrometheusMonitoredAgent._shared_metrics['memory_usage']
        self.active_sessions = PrometheusMonitoredAgent._shared_metrics['active_sessions']
        self.error_counter = PrometheusMonitoredAgent._shared_metrics['error_counter']
        self.sql_generation_time = PrometheusMonitoredAgent._shared_metrics['sql_generation_time']
        self.sql_execution_time = PrometheusMonitoredAgent._shared_metrics['sql_execution_time']
        self.answer_generation_time = PrometheusMonitoredAgent._shared_metrics['answer_generation_time']

    def _start_metrics_server(self):
        """Start Prometheus metrics HTTP server"""
        try:
            # Use default registry
            start_http_server(self.metrics_port)
            print(f"✅ Metrics server started on port {self.metrics_port}")
            print(f"🔗 Metrics URL: http://localhost:{self.metrics_port}/metrics")
        except OSError as e:
            if "Address already in use" in str(e):
                print(f"⚠️ Metrics server already running on port {self.metrics_port}")
            else:
                print(f"❌ Failed to start metrics server: {e}")

    def _start_system_monitoring(self):
        """Start background system monitoring"""
        def monitor_system():
            while True:
                try:
                    # CPU usage
                    cpu_percent = psutil.cpu_percent(interval=1)
                    self.cpu_usage.set(cpu_percent)

                    # Memory usage
                    memory = psutil.virtual_memory()
                    self.memory_usage.set(memory.used)

                except Exception as e:
                    print(f"System monitoring error: {e}")

                time.sleep(5)  # Update every 5 seconds

        monitor_thread = threading.Thread(target=monitor_system, daemon=True)
        monitor_thread.start()
        print("✅ System monitoring started")

    def query(self, question: str, stream: bool = False):
        """Execute query with comprehensive monitoring"""
        start_time = time.time()
        status = "success"
        error_type = None

        try:
            # Track question length
            self.question_length.observe(len(question))

            # Time the overall query
            with self.query_duration.labels(session_id=self.session_id).time():

                # SQL Generation timing
                sql_start = time.time()

                # Call the base agent (this includes SQL generation)
                result = self.agent.query(question)

                sql_gen_time = time.time() - sql_start
                self.sql_generation_time.observe(sql_gen_time)

                # Since the base agent combines SQL execution with generation,
                # we'll estimate execution time as a portion of total time
                sql_exec_time = sql_gen_time * 0.3  # Rough estimate
                self.sql_execution_time.observe(sql_exec_time)

                # Answer generation time (remaining time)
                answer_gen_time = sql_gen_time * 0.1  # Rough estimate
                self.answer_generation_time.observe(answer_gen_time)

                # Add metadata to result
                total_time = time.time() - start_time
                result['metadata'] = {
                    'total_time': total_time,
                    'sql_generation_time': sql_gen_time,
                    'sql_execution_time': sql_exec_time,
                    'answer_generation_time': answer_gen_time,
                    'session_id': self.session_id,
                    'csv_file': self.csv_path
                }

                print(f"📊 Metrics recorded for session {self.session_id}")

        except Exception as e:
            status = "error"
            error_type = type(e).__name__

            # Track the error
            self.error_counter.labels(
                error_type=error_type,
                session_id=self.session_id
            ).inc()

            # Return error result
            result = {
                'error': str(e),
                'error_type': error_type,
                'metadata': {
                    'total_time': time.time() - start_time,
                    'session_id': self.session_id,
                    'csv_file': self.csv_path
                }
            }

            print(f"Query error: {e}")

        finally:
            # Always increment query counter
            self.query_counter.labels(
                status=status,
                session_id=self.session_id
            ).inc()
            
            print(f"✅ Query completed - Status: {status}, Session: {self.session_id}")

        return result

    def get_metrics_url(self):
        """Get the metrics endpoint URL"""
        return f"http://localhost:{self.metrics_port}/metrics"

    def shutdown(self):
        """Clean shutdown"""
        try:
            if hasattr(self, 'active_sessions') and self.active_sessions:
                self.active_sessions.dec()
            print(f"Agent metrics shut down for session {self.session_id}")
        except Exception as e:
            print(f"Error during shutdown: {e}")

    @classmethod
    def reset_shared_state(cls):
        """Reset shared state (useful for testing)"""
        cls._metrics_server_started = False
        cls._shared_metrics = {}
        print("🔄 Shared state reset")

    @classmethod
    def get_current_metrics_summary(cls):
        """Get current metrics summary for debugging"""
        if cls._shared_metrics:
            print("📊 Current Metrics Summary:")
            print(f"  Active Sessions: {cls._shared_metrics.get('active_sessions', 'N/A')}")
            print(f"  Metrics initialized: {len(cls._shared_metrics)} metrics")
        else:
            print("❌ No metrics initialized")