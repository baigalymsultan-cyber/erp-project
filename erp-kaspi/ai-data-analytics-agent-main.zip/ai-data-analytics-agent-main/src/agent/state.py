from typing_extensions import TypedDict, Annotated
from typing import List
from langchain.schema import Document

class State(TypedDict):
    question: str
    query: str
    result: List[Document]
    answer: str

class QueryOutput(TypedDict):
    query: Annotated[str, ..., "Syntactically valid SQL query."]